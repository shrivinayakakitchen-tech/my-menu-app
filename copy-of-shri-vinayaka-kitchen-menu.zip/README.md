# Shri Vinayaka Kitchen - Digital Menu

Welcome to the official repository for the Shri Vinayaka Kitchen's interactive digital menu. This web application provides a clean, modern, and easy-to-use interface for customers to browse the delicious, home-cooked vegetarian meals available.

## 📜 Description

This project is a single-page web application designed to replace a traditional paper menu. It's built with modern web technologies to be fast, responsive, and accessible on any device, from mobile phones to desktop computers.

### ✨ Key Features

-   **Interactive Browsing:** A full menu categorized for easy navigation.
-   **Live Search:** Instantly find any dish by typing in the search bar.
-   **Category Filters:** Quickly filter the menu by categories like "Breakfast," "Thali," "Pizzas," and more.
-   **Dynamic Order Building:** Add items to your order and adjust quantities with a simple interface.
-   **Seamless WhatsApp Integration:** Once you've selected your items, a floating "Order Now" button generates a pre-filled WhatsApp message with your complete order and total price, ready to be sent.
-   **Suggestion Box:** Customers can easily send menu suggestions directly via WhatsApp.

## 🚀 How to Use the Menu

1.  **Browse the Menu:** Simply scroll down to see all the available dishes, grouped by category.
2.  **Filter Categories:** Click on the filter buttons (e.g., "Starters", "Rice") at the top to view only the items from that category. Click "All" to see the full menu again.
3.  **Search for a Dish:** Use the search bar to type the name of a dish you're looking for. The menu will update in real-time.
4.  **Add Items to Your Order:**
    -   Click the **"Add"** button next to a dish to add it to your order.
    -   Once an item is added, use the **`+`** and **`-`** buttons to adjust the quantity.
5.  **Place Your Order:**
    -   A green summary bar will appear at the bottom-right of the screen showing the number of items and the total price.
    -   When you are ready, click the **"Order Now"** button. This will open WhatsApp with a message containing your order details, which you can send directly to the kitchen.

## 🛠️ Technology & Hosting

This is a static web application built using **React** (via CDN), **TypeScript**, and **Tailwind CSS**. It does not require a backend server.

The application is hosted for free using **GitHub Pages**.
